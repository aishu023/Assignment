package com.cg.homeloan.dto;

import lombok.Data;

@Data
public class ConnectDTO {
	private Long connectId;
	private String name;
	private String phnNo;
	private String emilId;
}
