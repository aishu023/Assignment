package com.cg.homeloan.dto;

import lombok.Data;

@Data
public class PropertyResponseDTO {

	private int propertyId;
	private String ftName;
	private String ltName;
	private String phoneNumber;
	private String mailId;

}