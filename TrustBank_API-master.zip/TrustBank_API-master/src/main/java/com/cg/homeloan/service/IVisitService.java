package com.cg.homeloan.service;

public interface IVisitService {

}
