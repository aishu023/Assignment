package com.cg.homeloan.repository;

public interface IVisitRepository {

}
